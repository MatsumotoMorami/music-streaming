import type { Metadata } from "next";
import Link from "next/link";
import Header from './Header.client';
import "./globals.css";

export const metadata: Metadata = {
  title: "m0ram1 Music Space",
  description: "共享音乐房间",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className="antialiased app-body"
      >
        <div className="app-shell">
          <header className="site-header">
            <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-6 py-4">
              <Link className="brand" href="/">
                <span className="brand-mark" aria-hidden="true">
                  <svg viewBox="0 0 24 24" role="img" aria-hidden="true">
                    <path d="M12 5v9" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                    <path d="M12 5c3 1.2 4.5 2.6 4.5 4.5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                    <circle cx="10.2" cy="17.3" r="2.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
                  </svg>
                </span>
                <span>共享音乐</span>
              </Link>
              <Header />
            </div>
          </header>
          <main>{children}</main>
        </div>
      </body>
    </html>
  );
}
